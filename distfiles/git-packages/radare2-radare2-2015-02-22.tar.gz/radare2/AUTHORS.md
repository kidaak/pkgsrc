Main developer (author and maintainer)
======================================
 - pancake <nopcode.org>

Honoric contributors
====================
 - xvilka
 - condret
 - jvoisin
 - nibble
 - earada

Contributors: (sorted by length)
================================
 - Anton Bolotinksy
 - Glyn Kennington
 - schrotthaufen
 - TheLemonMan
 - elektranox
 - neuroflip
 - timstrazz
 - esanfelix
 - Alexander
 - dkreuter
 - inisider
 - cosarara
 - montekki
 - rvalles
 - esteve
 - capi_x
 - rudi_s
 - vext01
 - 0xroot
 - milabs
 - Sirmy
 - l0gic
 - eddyb
 - graz
 - nion
 - oxff
 - pof
 - dso
 - dx
