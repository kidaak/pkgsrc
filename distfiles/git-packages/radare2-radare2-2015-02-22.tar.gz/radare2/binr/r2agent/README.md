r2agent
=======

BUGS
- not working on windows
- if agent crashes, children processes are still using the listen port

- files
  - debug
  - open
  - push
  - pull
  - list
  - delete
  - chmod
- processes
  - attach
  - kill
- sessions
  - list
  - close
