/* pancake // nopcode.org 2010 -- emit module for rcc */

#define ARCH_X86_64 1
#include "emit_x86.c"
