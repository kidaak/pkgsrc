# this example is not working!!1

getstr(,32){"foo"}

main@global(128) {
	.var0 = getstr();
	puts(.var0);
	puts("patata");
}
