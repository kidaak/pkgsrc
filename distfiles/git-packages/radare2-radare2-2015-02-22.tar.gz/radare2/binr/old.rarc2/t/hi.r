printf@alias(0x804400);
main@global(,32) {
	printf("Hello World\n");
}
