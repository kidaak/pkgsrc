# Stupid program that returns '3'
main@global() { 123; }
