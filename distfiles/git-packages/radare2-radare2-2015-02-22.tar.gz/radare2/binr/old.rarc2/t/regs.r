main@global() {
	.reg0 = 0;
	.reg1 = 1;
}
