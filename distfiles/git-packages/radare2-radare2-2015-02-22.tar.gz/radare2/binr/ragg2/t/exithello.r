/* Hello World */

exit@syscall(1);

main@global() {
	exit(2);
}
