/* pancake // nopcode.org 2010-2011 -- emit module for radare2/r_egg */

#define ARCH_X86_64 1
#include "emit_x86.c"
