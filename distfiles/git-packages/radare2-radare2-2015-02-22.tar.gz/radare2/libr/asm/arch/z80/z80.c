#define R_API_I static

#include "z80asm.c"
#include "disasm.c"
