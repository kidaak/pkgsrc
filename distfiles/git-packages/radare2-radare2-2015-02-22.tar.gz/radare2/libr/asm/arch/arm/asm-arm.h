#ifndef _INCLUDE_ARMASS_H_
#define _INCLUDE_ARMASS_H_

int armass_assemble(const char *str, unsigned long off, int thumb);

#endif
